Ninja Ripper - 3D ripper


Web:     https://ninjaripper.com
Patreon: https://patreon.com/ninjaripper
Discord: https://discord.com/invite/u8kMqNm
Youtube: https://www.youtube.com/channel/UCgT-ET20KlC4AcECNtW9gyw

----------------------------------------
2.0.5 beta
----------------------------------------
Built-in support for dx9, dx8, d7 games
New importer options:
    Added NORMAL vector import settings
Added option to save textures without compression
Added option to save meshes separately with instancing
Fixed critical ripper bugs
Fixed critical bugs for blender addon


----------------------------------------
2.0.4 beta
----------------------------------------
Added saving meshes in local space (T-pose)
Added new import options
Improved support for ripping games:
  -If your game didn't rip or crash, try this version
Fixed bugs when ripping through dgVoodoo2 (DX 9/8/7/6 games)
Fixed bugs when ripping games from Origin


----------------------------------------
2.0.3 beta
----------------------------------------
Improved support for ripping games
    In previous version some meshs failed to save due incorrect indexes
Keys mapping
Improved import script
    You can use all texture coordinates. 
New injection method (D3D Wrapper as in NR1.7.1)
    Copy d3d11.dll from bin/wrapper directory to target exe dir and normally start target exe
Updates checker
Styles (qss) fixes


----------------------------------------
2.0.2 beta
----------------------------------------
Better games ripping support.
  -If your game crashed while ripping (eg Genshin Impact, Subnautica) try this version.
Instructions on how to create your own theme
Instructions on how to create your own localization (language)


----------------------------------------
2.0.1 beta
----------------------------------------
Shader parameters dump (cbuffer)
  -Projection matrixes, skining etc
Ripper bug fix
  -Better output mesh validation

Import script bug fix (Update import script in blender)


----------------------------------------
2.0.0 beta
----------------------------------------
Initial release
D3D11 scene capture
DS/GS stage capture
Instanced draws capture
Shaders saving
Textures saving
Import to blender 2.7x, 2.8x, 2.9x

