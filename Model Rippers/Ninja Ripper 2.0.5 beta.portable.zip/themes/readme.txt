How to create new style

Style file is a CSS file
More info here https://doc.qt.io/qt-5/stylesheet-reference.html

How create new ripper theme:
1. Copy any existing theme to new file
2. Open in any text editor
3. Edit styles as needed
4. Save in Ninja Ripper themes directory
