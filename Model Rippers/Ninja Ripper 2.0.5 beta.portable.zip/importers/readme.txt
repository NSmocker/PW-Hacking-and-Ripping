Blender import script
REMOVE OLD VERSION BEFORE INSTALL

1.0.7
Refactoring
Largest mesh selection after import

1.0.6
Added blender support for Mac
Added backward compatibility with NR2.0.0-NR2.0.4
Added NORMAL vector import settings
Fixed critical bugs (None object error)

1.0.5
Mesh local space import (pre vertex shader)
World space import filters added


1.0.4
TEXCOORD + compIdx
VertexAttrib + compIdx

1.0.3
Far clip distance
Projection matrix transpose

1.0.2
Fixes

1.0.1
Blender crash fixed

1.0.0
Initial release
