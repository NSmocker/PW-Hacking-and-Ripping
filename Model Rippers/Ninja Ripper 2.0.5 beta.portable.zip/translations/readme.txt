How to create new language translation

1. Install Qt from https://www.qt.io/
2. Open nr_orig.ts in Qt Linguist
3. Translate messages
4. Compile and save [youlanguagename].qm file in translations directory of Ninja Ripper
5. After program restart new language will added in Settings/Language menu
